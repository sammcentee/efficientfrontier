# Backtesting findings

Source: CSV: legacy\_market\_prices.csv

Portfolio baseline: 2018-09-26. Evaluation returns: 2018-09-27 to 2019-03-25 (128 observations).

## Market benchmarks

Evaluation baseline: 2018-09-26. Last observation: 2019-03-25. Benchmark paths use the same dates as the portfolio paths.

SPY and QQQ are USD ETF proxies for the S&amp;P 500 and Nasdaq-100. They are not index series.

Benchmark markers use the same dates and return objective as each frontier chart. The independent ETF references do not follow portfolio weight limits.

Stock frontier volatility uses the configured model covariance. ETF marker volatility uses the ordinary sample variance. With covariance shrinkage, these are different risk estimates. ETF positions are not scaled to match portfolio volatility.

Backtest benchmarks stay in cash for the first interval, pay the same entry fee rate as the portfolios, then hold. No terminal sale occurs.

| benchmark | Total return | CAGR | Annual volatility | Sharpe | Sortino | Calmar | Maximum drawdown | Fees / initial capital |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| S&amp;P 500 (SPY) | 10.60% | 21.94% | 18.40% | 1.007 | 1.397 | 2.149 | -10.21% | 0.15% |
| Nasdaq-100 (QQQ) | 5.59% | 11.30% | 22.72% | 0.452 | 0.630 | 0.881 | -12.82% | 0.15% |

## Evidence against benchmarks

Relative wealth divides portfolio value by benchmark value after both start at one. A value above one means the portfolio is ahead.

Annual mean advantage is the arithmetic mean return difference times observations per year. It is not the CAGR difference.

Inference requires at least 60 return observations. The 95% HAC confidence intervals are pointwise, not simultaneous bands.

HAC uses 4 lags for serial correlation and unequal return variance. Holm correction covers 96 tests across all strategy/benchmark pairs and both mean-advantage and alpha hypotheses.

Inference uses 127 paired returns from 2018-09-28 to 2019-03-25.

The p-values do not measure the probability of future outperformance. These estimates describe the observed sample and use large-sample approximations.

Alpha uses a separate excess-return regression for each benchmark. Beta measures only exposure to that benchmark. Positive alpha does not establish investment skill.

The 3 chronological windows describe consistency within the evaluated sample. They are not independent replications of the strategy.

Inference omits the first evaluation session and its entry fee. Total returns, relative wealth, and window results retain entry costs.

Default comparison: Expanding window · Medium. This choice does not depend on realized returns.

| strategy | benchmark | Total return difference | CAGR difference | Annual mean advantage | Benchmark beta | Annual alpha | Annual tracking error | Information ratio | Inference observations | Mean inference note | Alpha inference note | Mean CI lower | Mean CI upper | Mean p-value | Alpha CI lower | Alpha CI upper | Alpha p-value | Windows ahead | Mean Holm p-value | Alpha Holm p-value | Historical evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Buy and hold · Minimum volatility | S&amp;P 500 (SPY) | -1.54 pp | -3.31 pp | -3.55 pp | 0.652 | 3.06% | 9.12% | -0.389 | 127 |  |  | -30.29 pp | +23.19 pp | 0.7947 | -15.36% | 21.48% | 0.7446 | 1/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Minimum volatility | Nasdaq-100 (QQQ) | +3.47 pp | +7.32 pp | +4.76 pp | 0.508 | 10.01% | 13.34% | 0.357 | 127 |  |  | -31.53 pp | +41.06 pp | 0.797 | -9.87% | 29.90% | 0.3237 | 1/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Maximum Sharpe | S&amp;P 500 (SPY) | -4.48 pp | -9.53 pp | -7.99 pp | 0.869 | -5.50% | 11.51% | -0.695 | 127 |  |  | -36.86 pp | +20.87 pp | 0.5873 | -33.99% | 22.98% | 0.705 | 1/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Maximum Sharpe | Nasdaq-100 (QQQ) | +0.53 pp | +1.11 pp | +0.32 pp | 0.705 | 3.47% | 13.09% | 0.024 | 127 |  |  | -33.83 pp | +34.46 pp | 0.9854 | -26.95% | 33.90% | 0.823 | 2/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Equal weight | S&amp;P 500 (SPY) | +10.25 pp | +23.24 pp | +17.76 pp | 0.927 | 19.14% | 9.04% | 1.964 | 127 |  |  | -5.32 pp | +40.84 pp | 0.1316 | -3.35% | 41.63% | 0.09535 | 2/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Equal weight | Nasdaq-100 (QQQ) | +15.26 pp | +33.87 pp | +26.07 pp | 0.728 | 28.98% | 11.67% | 2.233 | 127 |  |  | -6.57 pp | +58.72 pp | 0.1175 | 2.21% | 55.75% | 0.03386 | 2/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Low | S&amp;P 500 (SPY) | -1.54 pp | -3.31 pp | -3.55 pp | 0.652 | 3.06% | 9.12% | -0.389 | 127 |  |  | -30.29 pp | +23.19 pp | 0.7947 | -15.36% | 21.48% | 0.7446 | 1/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Low | Nasdaq-100 (QQQ) | +3.47 pp | +7.32 pp | +4.76 pp | 0.508 | 10.01% | 13.34% | 0.357 | 127 |  |  | -31.53 pp | +41.06 pp | 0.797 | -9.87% | 29.90% | 0.3237 | 1/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Medium | S&amp;P 500 (SPY) | -6.29 pp | -13.27 pp | -11.89 pp | 0.774 | -7.60% | 10.04% | -1.184 | 127 |  |  | -38.68 pp | +14.90 pp | 0.3844 | -32.19% | 17.00% | 0.545 | 1/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Medium | Nasdaq-100 (QQQ) | -1.28 pp | -2.64 pp | -3.58 pp | 0.631 | 0.37% | 12.33% | -0.290 | 127 |  |  | -36.86 pp | +29.71 pp | 0.8332 | -25.78% | 26.52% | 0.9779 | 1/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Highest | S&amp;P 500 (SPY) | +9.96 pp | +22.57 pp | +17.80 pp | 0.968 | 18.40% | 12.48% | 1.426 | 127 |  |  | -14.56 pp | +50.16 pp | 0.2809 | -14.27% | 51.08% | 0.2697 | 2/3 | 1 | 1 | No clear statistical advantage |
| Buy and hold · Highest | Nasdaq-100 (QQQ) | +14.97 pp | +33.20 pp | +26.12 pp | 0.775 | 28.52% | 13.77% | 1.897 | 127 |  |  | -11.63 pp | +63.86 pp | 0.1751 | -7.47% | 64.51% | 0.1204 | 2/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Minimum volatility | S&amp;P 500 (SPY) | -1.46 pp | -3.15 pp | -3.41 pp | 0.651 | 3.21% | 9.14% | -0.373 | 127 |  |  | -30.32 pp | +23.50 pp | 0.8037 | -15.45% | 21.87% | 0.7361 | 1/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Minimum volatility | Nasdaq-100 (QQQ) | +3.55 pp | +7.48 pp | +4.90 pp | 0.508 | 10.16% | 13.37% | 0.367 | 127 |  |  | -31.45 pp | +41.25 pp | 0.7916 | -9.89% | 30.21% | 0.3207 | 1/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Maximum Sharpe | S&amp;P 500 (SPY) | -4.59 pp | -9.76 pp | -8.17 pp | 0.871 | -5.71% | 11.73% | -0.697 | 127 |  |  | -37.97 pp | +21.62 pp | 0.5908 | -35.18% | 23.76% | 0.704 | 1/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Maximum Sharpe | Nasdaq-100 (QQQ) | +0.42 pp | +0.87 pp | +0.14 pp | 0.708 | 3.26% | 13.19% | 0.011 | 127 |  |  | -34.58 pp | +34.86 pp | 0.9936 | -27.96% | 34.47% | 0.8379 | 2/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Equal weight | S&amp;P 500 (SPY) | +9.00 pp | +20.29 pp | +15.63 pp | 0.919 | 17.18% | 8.70% | 1.796 | 127 |  |  | -6.94 pp | +38.20 pp | 0.1747 | -4.71% | 39.07% | 0.124 | 2/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Equal weight | Nasdaq-100 (QQQ) | +14.00 pp | +30.93 pp | +23.94 pp | 0.721 | 26.92% | 11.47% | 2.088 | 127 |  |  | -8.24 pp | +56.13 pp | 0.1448 | 0.72% | 53.12% | 0.04399 | 2/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Low | S&amp;P 500 (SPY) | -1.46 pp | -3.15 pp | -3.41 pp | 0.651 | 3.21% | 9.14% | -0.373 | 127 |  |  | -30.32 pp | +23.50 pp | 0.8037 | -15.45% | 21.87% | 0.7361 | 1/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Low | Nasdaq-100 (QQQ) | +3.55 pp | +7.48 pp | +4.90 pp | 0.508 | 10.16% | 13.37% | 0.367 | 127 |  |  | -31.45 pp | +41.25 pp | 0.7916 | -9.89% | 30.21% | 0.3207 | 1/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Medium | S&amp;P 500 (SPY) | -6.15 pp | -12.99 pp | -11.61 pp | 0.773 | -7.31% | 10.23% | -1.135 | 127 |  |  | -39.13 pp | +15.91 pp | 0.4083 | -32.72% | 18.11% | 0.5732 | 1/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Medium | Nasdaq-100 (QQQ) | -1.14 pp | -2.35 pp | -3.30 pp | 0.631 | 0.64% | 12.44% | -0.265 | 127 |  |  | -37.06 pp | +30.46 pp | 0.8482 | -26.21% | 27.50% | 0.9626 | 1/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Highest | S&amp;P 500 (SPY) | +6.57 pp | +14.66 pp | +12.15 pp | 0.969 | 12.75% | 12.70% | 0.957 | 127 |  |  | -21.51 pp | +45.81 pp | 0.4792 | -21.29% | 46.78% | 0.4629 | 2/3 | 1 | 1 | No clear statistical advantage |
| Fixed rebalance · Highest | Nasdaq-100 (QQQ) | +11.58 pp | +25.30 pp | +20.47 pp | 0.779 | 22.82% | 13.80% | 1.483 | 127 |  |  | -17.63 pp | +58.56 pp | 0.2924 | -14.00% | 59.65% | 0.2245 | 2/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Minimum volatility | S&amp;P 500 (SPY) | -1.13 pp | -2.44 pp | -2.83 pp | 0.645 | 3.91% | 9.14% | -0.310 | 127 |  |  | -29.85 pp | +24.19 pp | 0.8372 | -14.50% | 22.32% | 0.677 | 1/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Minimum volatility | Nasdaq-100 (QQQ) | +3.88 pp | +8.19 pp | +5.48 pp | 0.503 | 10.79% | 13.38% | 0.410 | 127 |  |  | -31.15 pp | +42.11 pp | 0.7693 | -9.09% | 30.66% | 0.2874 | 1/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Maximum Sharpe | S&amp;P 500 (SPY) | +7.58 pp | +17.01 pp | +13.71 pp | 0.935 | 14.95% | 12.34% | 1.111 | 127 |  |  | -17.37 pp | +44.79 pp | 0.3873 | -15.87% | 45.77% | 0.3417 | 2/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Maximum Sharpe | Nasdaq-100 (QQQ) | +12.59 pp | +27.64 pp | +22.02 pp | 0.753 | 24.66% | 13.63% | 1.615 | 127 |  |  | -14.65 pp | +58.70 pp | 0.2392 | -8.97% | 58.29% | 0.1507 | 2/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Equal weight | S&amp;P 500 (SPY) | +9.00 pp | +20.29 pp | +15.63 pp | 0.919 | 17.18% | 8.70% | 1.796 | 127 |  |  | -6.94 pp | +38.20 pp | 0.1747 | -4.71% | 39.07% | 0.124 | 2/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Equal weight | Nasdaq-100 (QQQ) | +14.00 pp | +30.93 pp | +23.94 pp | 0.721 | 26.92% | 11.47% | 2.088 | 127 |  |  | -8.24 pp | +56.13 pp | 0.1448 | 0.72% | 53.12% | 0.04399 | 2/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Low | S&amp;P 500 (SPY) | -1.13 pp | -2.44 pp | -2.83 pp | 0.645 | 3.91% | 9.14% | -0.310 | 127 |  |  | -29.85 pp | +24.19 pp | 0.8372 | -14.50% | 22.32% | 0.677 | 1/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Low | Nasdaq-100 (QQQ) | +3.88 pp | +8.19 pp | +5.48 pp | 0.503 | 10.79% | 13.38% | 0.410 | 127 |  |  | -31.15 pp | +42.11 pp | 0.7693 | -9.09% | 30.66% | 0.2874 | 1/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Medium | S&amp;P 500 (SPY) | -1.51 pp | -3.27 pp | -2.90 pp | 0.805 | 0.80% | 10.03% | -0.289 | 127 |  |  | -29.16 pp | +23.36 pp | 0.8285 | -22.98% | 24.59% | 0.9472 | 1/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Medium | Nasdaq-100 (QQQ) | +3.49 pp | +7.37 pp | +5.41 pp | 0.653 | 9.12% | 12.25% | 0.442 | 127 |  |  | -28.43 pp | +39.25 pp | 0.754 | -17.13% | 35.37% | 0.4958 | 2/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Highest | S&amp;P 500 (SPY) | +16.20 pp | +37.66 pp | +28.08 pp | 0.970 | 28.65% | 14.35% | 1.957 | 127 |  |  | -10.57 pp | +66.73 pp | 0.1545 | -10.05% | 67.36% | 0.1467 | 2/3 | 1 | 1 | No clear statistical advantage |
| Expanding window · Highest | Nasdaq-100 (QQQ) | +21.21 pp | +48.29 pp | +36.39 pp | 0.779 | 38.76% | 15.38% | 2.367 | 127 |  |  | -6.07 pp | +78.86 pp | 0.09302 | -2.12% | 79.63% | 0.06312 | 2/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Minimum volatility | S&amp;P 500 (SPY) | -1.23 pp | -2.65 pp | -3.00 pp | 0.654 | 3.57% | 8.86% | -0.339 | 127 |  |  | -28.89 pp | +22.89 pp | 0.8202 | -13.83% | 20.97% | 0.6874 | 1/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Minimum volatility | Nasdaq-100 (QQQ) | +3.78 pp | +7.98 pp | +5.31 pp | 0.512 | 10.53% | 13.09% | 0.406 | 127 |  |  | -30.37 pp | +40.99 pp | 0.7705 | -8.58% | 29.63% | 0.2802 | 1/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Maximum Sharpe | S&amp;P 500 (SPY) | -0.04 pp | -0.08 pp | +0.97 pp | 0.983 | 1.30% | 14.92% | 0.065 | 127 |  |  | -39.11 pp | +41.06 pp | 0.962 | -38.50% | 41.09% | 0.949 | 1/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Maximum Sharpe | Nasdaq-100 (QQQ) | +4.97 pp | +10.55 pp | +9.29 pp | 0.809 | 11.33% | 15.21% | 0.610 | 127 |  |  | -32.74 pp | +51.32 pp | 0.665 | -29.36% | 52.03% | 0.5852 | 2/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Equal weight | S&amp;P 500 (SPY) | +9.00 pp | +20.29 pp | +15.63 pp | 0.919 | 17.18% | 8.70% | 1.796 | 127 |  |  | -6.94 pp | +38.20 pp | 0.1747 | -4.71% | 39.07% | 0.124 | 2/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Equal weight | Nasdaq-100 (QQQ) | +14.00 pp | +30.93 pp | +23.94 pp | 0.721 | 26.92% | 11.47% | 2.088 | 127 |  |  | -8.24 pp | +56.13 pp | 0.1448 | 0.72% | 53.12% | 0.04399 | 2/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Low | S&amp;P 500 (SPY) | -1.23 pp | -2.65 pp | -3.00 pp | 0.654 | 3.57% | 8.86% | -0.339 | 127 |  |  | -28.89 pp | +22.89 pp | 0.8202 | -13.83% | 20.97% | 0.6874 | 1/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Low | Nasdaq-100 (QQQ) | +3.78 pp | +7.98 pp | +5.31 pp | 0.512 | 10.53% | 13.09% | 0.406 | 127 |  |  | -30.37 pp | +40.99 pp | 0.7705 | -8.58% | 29.63% | 0.2802 | 1/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Medium | S&amp;P 500 (SPY) | -4.88 pp | -10.37 pp | -8.81 pp | 0.866 | -6.27% | 11.08% | -0.795 | 127 |  |  | -36.79 pp | +19.17 pp | 0.5372 | -33.16% | 20.62% | 0.6476 | 1/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Medium | Nasdaq-100 (QQQ) | +0.13 pp | +0.27 pp | -0.50 pp | 0.705 | 2.65% | 12.62% | -0.039 | 127 |  |  | -34.87 pp | +33.87 pp | 0.9775 | -26.69% | 31.99% | 0.8594 | 2/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Highest | S&amp;P 500 (SPY) | +6.15 pp | +13.71 pp | +12.17 pp | 1.037 | 11.47% | 16.20% | 0.752 | 127 |  |  | -30.64 pp | +54.98 pp | 0.5773 | -31.31% | 54.25% | 0.5993 | 2/3 | 1 | 1 | No clear statistical advantage |
| Rolling window · Highest | Nasdaq-100 (QQQ) | +11.16 pp | +24.34 pp | +20.49 pp | 0.851 | 22.08% | 16.25% | 1.261 | 127 |  |  | -24.01 pp | +64.98 pp | 0.3668 | -21.60% | 65.76% | 0.3218 | 2/3 | 1 | 1 | No clear statistical advantage |

### Historical windows

| Strategy | Benchmark | Window | Start | End | Observations | Relative wealth change | Annual mean advantage |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Buy and hold · Minimum volatility | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.76% | -11.19 pp |
| Buy and hold · Minimum volatility | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -6.27% | -38.58 pp |
| Buy and hold · Minimum volatility | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 7.10% | +40.22 pp |
| Buy and hold · Minimum volatility | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.59% | -23.12 pp |
| Buy and hold · Minimum volatility | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | -2.86% | -18.31 pp |
| Buy and hold · Minimum volatility | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 10.29% | +56.82 pp |
| Buy and hold · Maximum Sharpe | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -2.59% | -15.39 pp |
| Buy and hold · Maximum Sharpe | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -1.85% | -10.83 pp |
| Buy and hold · Maximum Sharpe | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 0.36% | +2.68 pp |
| Buy and hold · Maximum Sharpe | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -4.40% | -27.32 pp |
| Buy and hold · Maximum Sharpe | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 1.73% | +9.43 pp |
| Buy and hold · Maximum Sharpe | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 3.34% | +19.28 pp |
| Buy and hold · Equal weight | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -0.39% | -2.12 pp |
| Buy and hold · Equal weight | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | 2.83% | +16.57 pp |
| Buy and hold · Equal weight | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 6.67% | +38.91 pp |
| Buy and hold · Equal weight | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -2.24% | -14.04 pp |
| Buy and hold · Equal weight | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 6.57% | +36.83 pp |
| Buy and hold · Equal weight | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 9.85% | +55.51 pp |
| Buy and hold · Low | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.76% | -11.19 pp |
| Buy and hold · Low | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -6.27% | -38.58 pp |
| Buy and hold · Low | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 7.10% | +40.22 pp |
| Buy and hold · Low | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.59% | -23.12 pp |
| Buy and hold · Low | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | -2.86% | -18.31 pp |
| Buy and hold · Low | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 10.29% | +56.82 pp |
| Buy and hold · Medium | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -4.66% | -28.45 pp |
| Buy and hold · Medium | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -3.87% | -23.47 pp |
| Buy and hold · Medium | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 2.91% | +17.20 pp |
| Buy and hold · Medium | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -6.43% | -40.37 pp |
| Buy and hold · Medium | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | -0.37% | -3.21 pp |
| Buy and hold · Medium | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 5.97% | +33.80 pp |
| Buy and hold · Highest | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.48% | -8.22 pp |
| Buy and hold · Highest | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | 4.98% | +29.14 pp |
| Buy and hold · Highest | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 5.40% | +32.41 pp |
| Buy and hold · Highest | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.31% | -20.14 pp |
| Buy and hold · Highest | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 8.80% | +49.40 pp |
| Buy and hold · Highest | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 8.54% | +49.01 pp |
| Fixed rebalance · Minimum volatility | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.79% | -11.36 pp |
| Fixed rebalance · Minimum volatility | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -6.33% | -38.90 pp |
| Fixed rebalance · Minimum volatility | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 7.26% | +41.14 pp |
| Fixed rebalance · Minimum volatility | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.62% | -23.29 pp |
| Fixed rebalance · Minimum volatility | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | -2.91% | -18.64 pp |
| Fixed rebalance · Minimum volatility | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 10.45% | +57.74 pp |
| Fixed rebalance · Maximum Sharpe | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -2.63% | -15.64 pp |
| Fixed rebalance · Maximum Sharpe | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -1.75% | -10.19 pp |
| Fixed rebalance · Maximum Sharpe | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 0.19% | +1.73 pp |
| Fixed rebalance · Maximum Sharpe | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -4.44% | -27.56 pp |
| Fixed rebalance · Maximum Sharpe | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 1.83% | +10.07 pp |
| Fixed rebalance · Maximum Sharpe | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 3.17% | +18.33 pp |
| Fixed rebalance · Equal weight | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -0.30% | -1.62 pp |
| Fixed rebalance · Equal weight | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | 2.11% | +12.42 pp |
| Fixed rebalance · Equal weight | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 6.21% | +36.20 pp |
| Fixed rebalance · Equal weight | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -2.15% | -13.54 pp |
| Fixed rebalance · Equal weight | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 5.83% | +32.69 pp |
| Fixed rebalance · Equal weight | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 9.37% | +52.81 pp |
| Fixed rebalance · Low | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.79% | -11.36 pp |
| Fixed rebalance · Low | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -6.33% | -38.90 pp |
| Fixed rebalance · Low | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 7.26% | +41.14 pp |
| Fixed rebalance · Low | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.62% | -23.29 pp |
| Fixed rebalance · Low | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | -2.91% | -18.64 pp |
| Fixed rebalance · Low | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 10.45% | +57.74 pp |
| Fixed rebalance · Medium | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -4.69% | -28.63 pp |
| Fixed rebalance · Medium | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -3.75% | -22.69 pp |
| Fixed rebalance · Medium | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 2.95% | +17.44 pp |
| Fixed rebalance · Medium | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -6.46% | -40.56 pp |
| Fixed rebalance · Medium | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | -0.25% | -2.43 pp |
| Fixed rebalance · Medium | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 6.01% | +34.04 pp |
| Fixed rebalance · Highest | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.57% | -8.79 pp |
| Fixed rebalance · Highest | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | 4.11% | +24.28 pp |
| Fixed rebalance · Highest | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 3.38% | +20.89 pp |
| Fixed rebalance · Highest | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.40% | -20.71 pp |
| Fixed rebalance · Highest | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 7.90% | +44.54 pp |
| Fixed rebalance · Highest | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 6.45% | +37.49 pp |
| Expanding window · Minimum volatility | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.72% | -10.93 pp |
| Expanding window · Minimum volatility | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -6.19% | -38.09 pp |
| Expanding window · Minimum volatility | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 7.36% | +41.62 pp |
| Expanding window · Minimum volatility | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.54% | -22.86 pp |
| Expanding window · Minimum volatility | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | -2.78% | -17.82 pp |
| Expanding window · Minimum volatility | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 10.55% | +58.22 pp |
| Expanding window · Maximum Sharpe | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -2.25% | -13.28 pp |
| Expanding window · Maximum Sharpe | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | 2.71% | +16.16 pp |
| Expanding window · Maximum Sharpe | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 6.44% | +38.49 pp |
| Expanding window · Maximum Sharpe | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -4.07% | -25.20 pp |
| Expanding window · Maximum Sharpe | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 6.45% | +36.43 pp |
| Expanding window · Maximum Sharpe | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 9.60% | +55.10 pp |
| Expanding window · Equal weight | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -0.30% | -1.62 pp |
| Expanding window · Equal weight | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | 2.11% | +12.42 pp |
| Expanding window · Equal weight | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 6.21% | +36.20 pp |
| Expanding window · Equal weight | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -2.15% | -13.54 pp |
| Expanding window · Equal weight | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 5.83% | +32.69 pp |
| Expanding window · Equal weight | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 9.37% | +52.81 pp |
| Expanding window · Low | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.72% | -10.93 pp |
| Expanding window · Low | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -6.19% | -38.09 pp |
| Expanding window · Low | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 7.36% | +41.62 pp |
| Expanding window · Low | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.54% | -22.86 pp |
| Expanding window · Low | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | -2.78% | -17.82 pp |
| Expanding window · Low | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 10.55% | +58.22 pp |
| Expanding window · Medium | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -4.50% | -27.43 pp |
| Expanding window · Medium | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -1.78% | -10.71 pp |
| Expanding window · Medium | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 5.15% | +30.27 pp |
| Expanding window · Medium | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -6.28% | -39.36 pp |
| Expanding window · Medium | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 1.80% | +9.56 pp |
| Expanding window · Medium | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 8.28% | +46.87 pp |
| Expanding window · Highest | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.57% | -8.79 pp |
| Expanding window · Highest | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | 7.45% | +43.18 pp |
| Expanding window · Highest | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 8.40% | +49.70 pp |
| Expanding window · Highest | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.40% | -20.71 pp |
| Expanding window · Highest | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 11.36% | +63.44 pp |
| Expanding window · Highest | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 11.63% | +66.30 pp |
| Rolling window · Minimum volatility | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.74% | -11.07 pp |
| Rolling window · Minimum volatility | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -6.04% | -37.15 pp |
| Rolling window · Minimum volatility | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 7.11% | +40.29 pp |
| Rolling window · Minimum volatility | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.57% | -23.00 pp |
| Rolling window · Minimum volatility | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | -2.62% | -16.88 pp |
| Rolling window · Minimum volatility | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 10.30% | +56.89 pp |
| Rolling window · Maximum Sharpe | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.49% | -20.83 pp |
| Rolling window · Maximum Sharpe | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | 4.06% | +24.53 pp |
| Rolling window · Maximum Sharpe | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | -0.46% | -0.84 pp |
| Rolling window · Maximum Sharpe | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -5.28% | -32.76 pp |
| Rolling window · Maximum Sharpe | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 7.85% | +44.80 pp |
| Rolling window · Maximum Sharpe | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 2.50% | +15.76 pp |
| Rolling window · Equal weight | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -0.30% | -1.62 pp |
| Rolling window · Equal weight | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | 2.11% | +12.42 pp |
| Rolling window · Equal weight | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 6.21% | +36.20 pp |
| Rolling window · Equal weight | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -2.15% | -13.54 pp |
| Rolling window · Equal weight | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 5.83% | +32.69 pp |
| Rolling window · Equal weight | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 9.37% | +52.81 pp |
| Rolling window · Low | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -1.74% | -11.07 pp |
| Rolling window · Low | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -6.04% | -37.15 pp |
| Rolling window · Low | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 7.11% | +40.29 pp |
| Rolling window · Low | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.57% | -23.00 pp |
| Rolling window · Low | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | -2.62% | -16.88 pp |
| Rolling window · Low | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 10.30% | +56.89 pp |
| Rolling window · Medium | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -4.57% | -27.82 pp |
| Rolling window · Medium | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | -1.41% | -8.10 pp |
| Rolling window · Medium | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 1.59% | +10.14 pp |
| Rolling window · Medium | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -6.34% | -39.75 pp |
| Rolling window · Medium | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 2.18% | +12.17 pp |
| Rolling window · Medium | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 4.62% | +26.74 pp |
| Rolling window · Highest | S&amp;P 500 (SPY) | 1 | 2018-09-27 | 2018-11-26 | 43 | -3.03% | -17.55 pp |
| Rolling window · Highest | S&amp;P 500 (SPY) | 2 | 2018-11-27 | 2019-01-24 | 43 | 8.85% | +51.36 pp |
| Rolling window · Highest | S&amp;P 500 (SPY) | 3 | 2019-01-25 | 2019-03-25 | 42 | 0.01% | +2.19 pp |
| Rolling window · Highest | Nasdaq-100 (QQQ) | 1 | 2018-09-27 | 2018-11-26 | 43 | -4.83% | -29.47 pp |
| Rolling window · Highest | Nasdaq-100 (QQQ) | 2 | 2018-11-27 | 2019-01-24 | 43 | 12.82% | +71.62 pp |
| Rolling window · Highest | Nasdaq-100 (QQQ) | 3 | 2019-01-25 | 2019-03-25 | 42 | 2.98% | +18.80 pp |

- These tests describe historical paths. They do not estimate the probability of future outperformance.
- Holm adjustment covers this report only. It does not account for prior strategy searches or repeated changes after review.
- HAC inference assumes consistently spaced observations and stable enough return relationships. Structural changes can invalidate the estimates.
- Statistical estimates exclude the first cash and entry interval. Full-path results and windows retain entry costs.
- At least one comparison window has less than one year of observations. Window results can be unstable.

## Observed findings

Best in hindsight. These results were picked after the test. They are not a recommendation.

- Highest net return in this sample: Expanding window · Highest, +26.80%. This was 7.21 percentage points above Expanding window · Equal weight.
- Smallest maximum drawdown in this sample: Fixed rebalance · Minimum volatility, -4.87% from a previous portfolio high.
- Largest positive holding contribution for Expanding window · Highest: S05, +24.87 percentage points of initial capital before fees.
- Largest holding detractor for Expanding window · Highest: S04, -2.38 percentage points of initial capital before fees.
- Trading for Expanding window · Highest: gross turnover 2.36× (summed traded-notional / pretrade-value ratios); modeled fees consumed 0.39% of initial capital (39.23 per 10,000 initial units).
- Largest observed closing position for Expanding window · Highest: S05, 42.98% of portfolio value; its largest target was 40.00%. Price changes can move realized weights above target limits.

These are retrospective comparisons; the selected strategy is not a forecast.

## All method and portfolio combinations

| Strategy | Net total return | CAGR | Annual volatility | Sharpe | Sortino | Calmar | Maximum drawdown | Gross turnover | Fees / initial capital | Allocation events (incl. entry) | Sharpe fallbacks |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Buy and hold · Minimum volatility | 9.06% | 18.62% | 13.62% | 1.10 | 1.56 | 3.82 | -4.88% | 1.00× | 0.15% | 1 | 0 |
| Buy and hold · Maximum Sharpe | 6.12% | 12.41% | 19.53% | 0.54 | 0.76 | 1.03 | -12.10% | 1.00× | 0.15% | 1 | 0 |
| Buy and hold · Equal weight | 20.85% | 45.18% | 19.26% | 1.88 | 2.70 | 6.12 | -7.39% | 1.00× | 0.15% | 1 | 0 |
| Buy and hold · Low | 9.06% | 18.62% | 13.62% | 1.10 | 1.56 | 3.82 | -4.88% | 1.00× | 0.15% | 1 | 0 |
| Buy and hold · Medium | 4.31% | 8.67% | 16.90% | 0.40 | 0.56 | 0.91 | -9.57% | 1.00× | 0.15% | 1 | 0 |
| Buy and hold · Highest | 20.56% | 44.51% | 21.73% | 1.67 | 2.38 | 4.33 | -10.28% | 1.00× | 0.15% | 1 | 0 |
| Fixed rebalance · Minimum volatility | 9.14% | 18.79% | 13.62% | 1.11 | 1.58 | 3.85 | -4.87% | 1.12× | 0.17% | 7 | 0 |
| Fixed rebalance · Maximum Sharpe | 6.01% | 12.18% | 19.68% | 0.53 | 0.74 | 0.99 | -12.33% | 1.15× | 0.17% | 7 | 0 |
| Fixed rebalance · Equal weight | 19.59% | 42.23% | 18.94% | 1.80 | 2.59 | 5.50 | -7.68% | 1.28× | 0.20% | 7 | 0 |
| Fixed rebalance · Low | 9.14% | 18.79% | 13.62% | 1.11 | 1.58 | 3.85 | -4.87% | 1.12× | 0.17% | 7 | 0 |
| Fixed rebalance · Medium | 4.45% | 8.95% | 17.00% | 0.41 | 0.58 | 0.94 | -9.57% | 1.17× | 0.18% | 7 | 0 |
| Fixed rebalance · Highest | 17.17% | 36.60% | 21.85% | 1.40 | 1.99 | 3.16 | -11.57% | 1.23× | 0.19% | 7 | 0 |
| Expanding window · Minimum volatility | 9.47% | 19.50% | 13.46% | 1.17 | 1.67 | 4.00 | -4.88% | 1.16× | 0.18% | 7 | 0 |
| Expanding window · Maximum Sharpe | 18.18% | 38.95% | 21.11% | 1.52 | 2.19 | 4.18 | -9.32% | 1.81× | 0.28% | 7 | 0 |
| Expanding window · Equal weight | 19.59% | 42.23% | 18.94% | 1.80 | 2.59 | 5.50 | -7.68% | 1.28× | 0.20% | 7 | 0 |
| Expanding window · Low | 9.47% | 19.50% | 13.46% | 1.17 | 1.67 | 4.00 | -4.88% | 1.16× | 0.18% | 7 | 0 |
| Expanding window · Medium | 9.08% | 18.67% | 17.51% | 0.89 | 1.27 | 2.36 | -7.90% | 2.08× | 0.32% | 7 | 0 |
| Expanding window · Highest | 26.80% | 59.60% | 22.86% | 2.03 | 3.00 | 6.74 | -8.85% | 2.36× | 0.39% | 7 | 0 |
| Rolling window · Minimum volatility | 9.37% | 19.29% | 13.50% | 1.15 | 1.65 | 3.95 | -4.88% | 1.38× | 0.21% | 7 | 0 |
| Rolling window · Maximum Sharpe | 10.56% | 21.85% | 23.41% | 0.83 | 1.19 | 1.69 | -12.93% | 2.80× | 0.45% | 7 | 0 |
| Rolling window · Equal weight | 19.59% | 42.23% | 18.94% | 1.80 | 2.59 | 5.50 | -7.68% | 1.28× | 0.20% | 7 | 0 |
| Rolling window · Low | 9.37% | 19.29% | 13.50% | 1.15 | 1.65 | 3.95 | -4.88% | 1.38× | 0.21% | 7 | 0 |
| Rolling window · Medium | 5.72% | 11.57% | 19.23% | 0.51 | 0.71 | 1.14 | -10.19% | 2.95× | 0.45% | 7 | 0 |
| Rolling window · Highest | 16.75% | 35.65% | 24.99% | 1.22 | 1.77 | 2.87 | -12.44% | 2.76× | 0.45% | 7 | 0 |

## Holdings for Expanding window · Highest

Up to 10 largest absolute P&L contributions are shown, restricted to assets targeted above 0.0001%. Contributions use initial capital as the denominator, with trading fees accounted for separately. The CSV export contains all holdings.

| Asset | P&amp;L / initial capital | Average weight | End weight | Selection frequency | Maximum target weight | Maximum realized weight |
| --- | --- | --- | --- | --- | --- | --- |
| S05 | 24.87% | 31.28% | 42.26% | 100.00% | 40.00% | 42.98% |
| S03 | 3.44% | 26.04% | 19.43% | 85.71% | 40.00% | 42.39% |
| S04 | -2.38% | 38.85% | 38.31% | 100.00% | 40.00% | 40.67% |
| S07 | 1.26% | 3.04% | 0.00% | 14.29% | 20.00% | 20.11% |

## Settings

- train\_fraction: 0.6
- risk\_free\_rate: 0.03
- max\_weight: 0.4
- shrinkage: 0.1
- rebalance\_every: 20
- rolling\_window: 192
- cost\_bps: 15.0
- split: 192
- include\_profiles: True
- profile\_return\_objective: historical\_mean
- periods\_per\_year: 252.0
- trading\_days\_per\_year: 252.0
- cash\_interest\_rate: 0.0
- train\_start: 2018-01-02
- train\_end: 2018-09-26
- test\_start: 2018-09-27
- test\_end: 2019-03-25
- initial\_execution: 2018-09-27
- execution: Prior-close information; execute at the following close; first session in cash.
- cost\_convention: Basis points per absolute dollar bought or sold; entry included; no final liquidation.

## Assumptions and interpretation

Buy and hold allocates once. Fixed rebalance restores the original fitted targets at each scheduled trade. Expanding window refits using all prior observations; rolling window refits using only the most recent configured number of returns. Rebalance intervals count observed sessions, not calendar months. Fixed-rebalance, expanding-window and rolling-window equal-weight baselines coincide because they use the same targets and schedule.

All methods use the same evaluation dates and fixed input universe. Targets use information through the prior close and execute at the following close. The first evaluation session is held in cash earning zero interest. Weights drift between trades; no execution-day return is earned using the new target.

Trading fees are deducted from portfolio wealth. Gross turnover counts both purchases and sales, each divided by portfolio value before that trade and summed across events. Entry is included and terminal liquidation is excluded. Fees are shown as a share of initial capital. Asset P&L contributions, less fees, reconcile to the net total return. The fee total excludes foregone compounding, so it does not measure the full performance difference from a zero-fee run. Taxes, FX conversion and liquidity constraints are not modeled.

Average weight uses exposure at the start of each evaluation session, including the initial cash session. Selection frequency is the share of allocation events with an asset target above 0.0001%; it is not the fraction of observations held.

Prices must be adjusted and share a common currency basis. A fixed universe can introduce survivorship bias.

These findings describe the evaluated sample. The highest-return strategy is selected after evaluation; it is not a forecast or a recommendation to hold its assets. Repeated strategy selection using these results can overfit the evaluation period.

Low, Medium, and Highest use the same historical arithmetic mean return objective as the primary latest holdings. Low selects minimum fitted volatility, Medium selects the sampled point nearest the midpoint of endpoint volatility, and Highest selects maximum fitted arithmetic mean return. Three-window estimates are diagnostics, not optimization targets. These are relative risk levels within each fit, not universal risk ratings. Profile backtests fit only the history available before each allocation. The latest model holdings use all supplied history and remain separate from these backtests and the original holdout.

CAGR and volatility use 252 observations per year. Sortino measures excess return relative to downside deviation. Calmar divides CAGR by the absolute maximum drawdown. An em dash marks a ratio with a zero denominator.

## Study notes

- 2018-09-27 · Buy and hold · Profiles: At least one historical window has less than one year of observations. Estimates can be unstable.
